<?php

namespace home;

class Setting{
	
	public static function getPerfix(){
		return "§l§a¡§cH§fo§cm§fe§a¡ §b»§f ";
	}
	
	public static function getCD(){
		return (int)20;
	}
}