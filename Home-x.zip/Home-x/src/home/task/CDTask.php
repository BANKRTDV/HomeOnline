<?php

namespace home\task;

use home\Main;
use pocketmine\scheduler\Task;

class CDTask extends Task{

	private $plugin;

	public function __construct(Main $plugin){
		$this->plugin = $plugin;
	}

	public function onRun(int $tick){
		$this->plugin->timer();
	}
}