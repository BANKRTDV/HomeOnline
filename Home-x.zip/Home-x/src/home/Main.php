<?php

namespace home;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;
use pocketmine\event\player\PlayerJoinEvent;
use home\Setting;
use pocketmine\level\Position;
use home\task\CDTask;

class Main extends PluginBase implements Listener {
	
	public function onEnable(){	
		$this->getLogger()->info("Load...");
		
		@mkdir($this->getDataFolder());
		@mkdir($this->getDataFolder() . "home_data");
		
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->form = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$this->getScheduler()->scheduleRepeatingTask(new CDTask($this), 21);
	}
	
	public $c = [];
	
	public function timer(){
	 //echo "\nCd";
		foreach($this->c as $name => $cd){
			// echo "\nName ".$name." Cd ".$cd;
			if($cd <= 0){
				$this->c[$name] = 0;
			}else{
				$this->c[$name] = $this->c[$name] - 1;
			}
		}
	}
	
	public function getCd($p){
		return $this->c[$p->getName()];
	}
	
	public function setCd($p, $cd){
		$this->c[$p->getName()] = $cd;
	}

	public function setFile(PlayerJoinEvent $e){	
		$p = $e->getPlayer();
		$c = new Config($this->getDataFolder() . "home_data/".strtolower($p->getName()).".yml", Config::YAML);
		$c->save();
		$this->setCd($p, 0);
	}
	
	public function saveHome($p, $home_name){	
		$c = new Config($this->getDataFolder() . "home_data/".strtolower($p->getName()).".yml", Config::YAML);
		$c->set($home_name, ["pos"=>["x"=>(float)$p->x,
									 "y"=>(float)($p->y+1),
								     "z"=>(float)$p->z,
									 "world"=>$p->getLevel()->getName()]
								 ]);
		$c->save();
	}
	
	public function removeHome($p, $home_name){	
		$c = new Config($this->getDataFolder() . "home_data/".strtolower($p->getName()).".yml", Config::YAML);
		if(!$c->exists($home_name)){
			$p->sendMessage(Setting::getPerfix(). "ไม่พบบ้านที่บันทึก");
			return true;
		}
		$c->remove($home_name);
		$c->save();
		$p->sendMessage(Setting::getPerfix(). "ลบบ้าน ".$home_name." สำเร็จ");
	}
	
	public function goHome($p, $home_name){	
		$c = new Config($this->getDataFolder() . "home_data/".strtolower($p->getName()).".yml", Config::YAML);
		if(!$c->exists($home_name)){
			$p->sendMessage(Setting::getPerfix(). "ไม่พบบ้านที่บันทึก");
			return true;
		}
		$arr = $c->get($home_name);
		$level = $this->getServer()->getLevelByName($arr["pos"]["world"]);
		$p->teleport(new Position($arr["pos"]["x"], $arr["pos"]["y"], $arr["pos"]["z"], $level));
		$p->sendMessage(Setting::getPerfix(). "กำลังพากลับบ้าน...");
		$p->setFlying(false);
        $p->setAllowFlight(false);
	}
	
	public function getHomeAll($p){	
		$c = new Config($this->getDataFolder() . "home_data/".strtolower($p->getName()).".yml", Config::YAML);
		$mess = "";
		foreach($c->getAll() as $home_name => $data){
			$mess .= " , ".$home_name;
		}
		return $mess;
	}
	
	
	public function goHomeSee($p, $name, $home_name){	
		$c = new Config($this->getDataFolder() . "home_data/".strtolower($name).".yml", Config::YAML);
		if(!$c->exists($home_name)){
			$p->sendMessage(Setting::getPerfix(). "ไม่พบบ้านผู้เล่นที่บันทึก");
			return true;
		}
		if($this->getCd($p) > 0){
			$p->sendMessage(Setting::getPerfix(). "รออีก ".$this->getCd($p)." วินาที เพื่อไปบ้านผู้เล่นคนอื่น");
			return true;
		}
		$arr = $c->get($home_name);
		$level = $this->getServer()->getLevelByName($arr["pos"]["world"]);
		$p->teleport(new Position($arr["pos"]["x"], $arr["pos"]["y"], $arr["pos"]["z"], $level));
		$p->sendMessage(Setting::getPerfix(). "กำลังไปบ้านผู้เล่น ".$name."...");
		$p->setFlying(false);
        $p->setAllowFlight(false);
		$this->setCd($p, Setting::getCD());
	}

	public function onCommand(CommandSender $s, Command $c, string $label, array $a) : bool{
		if($c->getName() == "home" ){
			$this->showForm($s);
		}
		return true;
	}

	public function showForm($player){
		$form = $this->form->createSimpleForm(function (Player $player, int $data = null){
			$result = $data;
			if($result === null){
				return true;
			}
			switch($result){
				case "0";
				$this->goHomeForm($player);
				break;
				case "1";
				$this->saveHomeForm($player);
				break;
				case "2";
				$this->removeForm($player);
				break;
				case "3";
				$this->seeForm($player);
				break;
			}
		});
		$form->setTitle("§l§cH§6o§em§ae");
		$form->setContent("§l§fหน้าต่างคำสั่งบ้าน\nสำหลับบันทึกจุดวาปของบ้าน\nเเละสามารถวาปไปบ้านคนอื่นๆได้");
		$form->addButton("§l§4Back to Home\n§l§0กลับบ้านของคุณ", 0, "textures/ui/Friend1.png");
		$form->addButton("§l§4Save Home\n§l§0บันทึกบ้านของคุณ", 0, "textures/ui/Friend1.png");
		$form->addButton("§l§4Remove Home\n§l§0ลบบ้านของคุณ", 0, "textures/ui/Friend1.png");
		$form->addButton("§l§4See Home\n§l§0ดูบ้านผู้เล่นที่ออนไลน์",0, "textures/ui/FriendsIcon.png");
		$form->sendToPlayer($player);
	}
	
	public $pData = [];

	public function seeForm($player){
		$form = $this->form->createSimpleForm(function (Player $player, $data = null){
			$result = $data[0];
			if($result === null){
				return true;
				}
				$name = $this->sor[$player->getName()] = $data;
				$this->goHomeSeeForm($player, $name);
			});
			$form->setTitle("§l§0See Home");
			$form->setContent(" ");
			foreach($this->getServer()->getOnlinePlayers() as $online){
				$form->addButton($online->getName(), -1, "", $online->getName());
			}
			$form->sendToPlayer($player);
	}
	
	public function goHomeSeeForm($player, $name){
		$form = $this->form->createCustomForm(function (Player $player, array $data = null) use ($name){
			$result = $data[0];
			if($result === null){
				return true;
				}
				if($data[0] == ""){
					$player->sendMessage(Setting::getPerfix(). "โปรดเขียนชื่อด้านบน");
					return true;
				}
				$this->goHomeSee($player, $name, $data[0]);
			});
		$form->setTitle("§l§0Go Home §4".$name);
		$form->addInput($this->getHomeAll($player->getServer()->getPlayer($name))."\n\nเลือกชื่อด้านบนเพื่อวาป...", 0, 0);
		$form->sendToPlayer($player);
	}

	public function goHomeForm($player){
		$form = $this->form->createCustomForm(function (Player $player, array $data = null){
			$result = $data[0];
			if($result === null){
				return true;
				}
				if($data[0] == ""){
					$player->sendMessage(Setting::getPerfix(). "โปรดเขียนชื่อด้านบน");
					return true;
				}
				$this->goHome($player, $data[0]);
			});
		$form->setTitle("§l§0Go Home");
		$form->addInput($this->getHomeAll($player)."\n\nเลือกชื่อด้านบนเพื่อวาป", 0, 0);
		$form->sendToPlayer($player);
	}
	
	public function removeForm($player){
		$form = $this->form->createCustomForm(function (Player $player, array $data = null){
			$result = $data[0];
			if($result === null){
				return true;
				}
				if($data[0] == ""){
					$player->sendMessage(Setting::getPerfix(). "โปรดเขียนชื่อด้านบน");
					return true;
				}
				$this->removeHome($player, $data[0]);
			});
		$form->setTitle("§l§0Remove Home");
		$form->addInput($this->getHomeAll($player)."\n\nเลือกชื่อด้านบนเพื่อลบ", 0, 0);
		$form->sendToPlayer($player);
	}
	
	public function saveHomeForm($player){
		$form = $this->form->createCustomForm(function (Player $player, array $data = null){
			$result = $data[0];
			if($result === null){
				return true;
				}
				if($data[0] == ""){
					$player->sendMessage(Setting::getPerfix(). "กรุณาใส่ชื่อที่ต้องการบันทึก");
					return true;
				}
				$this->saveHome($player, $data[0]);
				$player->sendMessage(Setting::getPerfix(). "บันทึกบ้านเรียบร้อยเเล้ว...");
			});
		$form->setTitle("§l§0Save Home");
		$form->addInput("ไส่ชื่อที่ต้องการเพื่อบันทึก", 0, 0);
		$form->sendToPlayer($player);
	}
}